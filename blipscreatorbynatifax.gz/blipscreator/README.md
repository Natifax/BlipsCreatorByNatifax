------------------By Natifax------------------
----------https://discord.gg/zuveklandrp
--------https://txitch.tv/natifax
-------https://tiktok.com/natifax.officiel

||||--Me--||||   
- 👋 Hi, I’m @Natifax
- 👀 I’m interested in ...
- 🌱 I’m currently learning ...
- 💞️ I’m looking to collaborate on ...
- 📫 How to reach me ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...

||||--ScriptBlips--||||

    ° Installation °

Download from the Github, and copy the easyblips directory in resources.
Put start blipscreator in the server.cfg file.
Enjoy! :smile:

    
        <!---
Natifax/Natifax is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
