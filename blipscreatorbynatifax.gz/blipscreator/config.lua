 Config = {}

Config.Locale = GetConvar('esx:locale', 'fr')

Config.Blips = {
	test = {coords = vector3(453.217590, 5572.061524, 795.761230), name = "~y~Blips~s~Testby~p~Natifax~s~", color = 36, sprite = 671}, -----Mont Chiliad-----      
}